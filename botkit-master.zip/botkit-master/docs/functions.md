# Botkit Controller

controller.middleware.*

controller.changeEars

controller.hears

controller.on

controller.trigger

controller.spawn

controller.receiveMessage

controller.version

controller.log

... and then platform specific features too



# Bot Object

bot.reply

bot.say

bot.startConversation

bot.createConversation

... and lots of specific featres added by platforms




# Conversation Object

convo.setVar

convo.activate

convo.isActive

convo.deactivate

convo.say

convo.sayFirst

convo.on

convo.trigger

convo.next

convo.repeat

convo.silentRepeat

convo.addQuestion

convo.ask

convo.setTimeout

convo.onTimeout

convo.hasThread

convo.transitionTo

convo.gotoThread

convo.getResponses

convo.getResponsesAsArray

convo.extractResponses

convo.extractResponse

convo.stop

convo.successful

convo.cloneMessage
